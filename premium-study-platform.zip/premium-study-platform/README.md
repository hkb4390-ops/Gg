# StudySpace — Premium Study Platform

A responsive React + TypeScript + Vite learning website connected to the supplied course API.

## API endpoints

- Status: `https://studyapkmod.free.nf/tbapi/api.php`
- Courses: `https://studyapkmod.free.nf/tbapi/api.php?courses`
- Course details: `https://studyapkmod.free.nf/tbapi/api.php?courseid=COURSE_ID`
- Video details: `https://studyapkmod.free.nf/tbapi/api.php?video=VIDEO_ID`

The sample course and video IDs are not hardcoded as universal IDs. The app uses IDs discovered in the API responses.

## Run locally

Requires a recent Node.js version.

```bash
npm install
npm run dev
```

## Production build

```bash
npm run build
npm run preview
```

## Deploy to Vercel

1. Upload the project to a GitHub repository.
2. Import the repository into Vercel.
3. Use the default Vite settings:
   - Build command: `npm run build`
   - Output directory: `dist`
4. Deploy. `vercel.json` includes SPA routing for nested routes.
5. If desired, add `VITE_API_BASE_URL` in Vercel Environment Variables.

## API / CORS note

The API endpoints returned `403 Forbidden` when checked from the assistant's web inspection environment, so the live response schema and playback format could not be verified here. The app is built to inspect and normalize common JSON shapes, but the real API may need adjustments if its field names or CORS policy differ. If the browser console shows a CORS error, the API host must permit the website's origin, or the API owner must provide a legitimate server-side proxy. This project does not use fake course or video data as a fallback.

## Supported behavior

- Course listing and search
- Dynamic course details and nested content exploration
- Video ID resolution and HTML5/HLS playback where supported by the returned URL
- Local watch history and resume position when the media player exposes playback events
- Loading, empty, retry, and API error states
- Responsive layout for mobile and desktop

The app cannot play sources that require unsupported DRM, authentication, or disallowed embedding.
