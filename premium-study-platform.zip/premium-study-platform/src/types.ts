export type Raw = Record<string, any>

export interface Course {
  id: string
  title: string
  description?: string
  thumbnail?: string
  teacher?: string
  category?: string
  raw: Raw
}

export interface ContentItem {
  id: string
  title: string
  kind: 'folder' | 'video' | 'item'
  thumbnail?: string
  duration?: string
  description?: string
  videoId?: string
  children: ContentItem[]
  raw: Raw
}

export interface VideoInfo {
  url: string
  title?: string
  type?: string
  raw: Raw
}
