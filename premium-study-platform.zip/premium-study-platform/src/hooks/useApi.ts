import { useCallback, useEffect, useState } from 'react'

export function useAsyncData<T>(loader: () => Promise<T>, deps: unknown[] = []) {
  const [data, setData] = useState<T | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [reloadKey, setReloadKey] = useState(0)
  const retry = useCallback(() => setReloadKey(v => v + 1), [])

  useEffect(() => {
    let active = true
    setLoading(true)
    setError('')
    loader().then(value => {
      if (active) setData(value)
    }).catch(err => {
      if (active) setError(err instanceof Error ? err.message : 'Could not load data.')
    }).finally(() => {
      if (active) setLoading(false)
    })
    return () => { active = false }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [...deps, reloadKey])

  return { data, loading, error, retry }
}
