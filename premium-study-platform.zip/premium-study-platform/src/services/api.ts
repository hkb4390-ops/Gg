import type { Course, ContentItem, VideoInfo, Raw } from '../types'

const BASE_URL = (import.meta.env.VITE_API_BASE_URL || 'https://studyapkmod.free.nf/tbapi/api.php').replace(/\/+$/, '')

function endpoint(params?: Record<string, string>) {
  const url = new URL(BASE_URL)
  if (params) Object.entries(params).forEach(([key, value]) => url.searchParams.set(key, value))
  return url.toString()
}

async function request(url: string): Promise<any> {
  const controller = new AbortController()
  const timer = window.setTimeout(() => controller.abort(), 18000)
  try {
    const response = await fetch(url, {
      method: 'GET',
      headers: { Accept: 'application/json, text/plain, */*' },
      signal: controller.signal,
      cache: 'no-store',
    })
    const text = await response.text()
    if (!response.ok) throw new Error(`API returned HTTP ${response.status}${text ? `: ${text.slice(0, 140)}` : ''}`)
    if (!text.trim()) return null
    try { return JSON.parse(text) } catch {
      try { return JSON.parse(text.replace(/^\uFEFF/, '')) } catch { return text }
    }
  } catch (error: any) {
    if (error?.name === 'AbortError') throw new Error('The API request took too long. Please try again.')
    if (error instanceof TypeError) throw new Error('Could not reach the API. This may be a network or CORS restriction.')
    throw error
  } finally {
    window.clearTimeout(timer)
  }
}

export const getApiStatus = () => request(endpoint())
export const getAllCoursesRaw = () => request(endpoint({ courses: '' }))
export const getCourseDetailsRaw = (courseId: string) => request(endpoint({ courseid: courseId }))
export const getVideoRaw = (videoId: string) => request(endpoint({ video: videoId }))

const asObject = (value: any): Raw => value && typeof value === 'object' && !Array.isArray(value) ? value : {}
const first = (obj: Raw, keys: string[]) => {
  for (const key of keys) {
    const value = obj[key]
    if (value !== undefined && value !== null && value !== '') return value
  }
  return undefined
}
const str = (value: any) => typeof value === 'string' || typeof value === 'number' ? String(value) : ''
const textField = (obj: Raw, keys: string[]) => str(first(obj, keys)).trim()
const idField = (obj: Raw) => textField(obj, ['id', '_id', 'course_id', 'courseId', 'video_id', 'videoId', 'uid', 'folder_id', 'item_id', 'content_id'])
const titleField = (obj: Raw) => textField(obj, ['title', 'name', 'course_name', 'courseName', 'subject_name', 'chapter_name', 'lecture_name', 'video_title', 'label', 'heading'])
const imageField = (obj: Raw) => {
  const value = textField(obj, ['thumbnail', 'thumb', 'thumbnail_url', 'thumbnailUrl', 'image', 'image_url', 'imageUrl', 'cover', 'banner', 'poster'])
  return isHttpUrl(value) ? value : ''
}
const descriptionField = (obj: Raw) => textField(obj, ['description', 'details', 'about', 'summary', 'subtitle'])
const videoIdField = (obj: Raw) => textField(obj, ['video_id', 'videoId', 'videoid', 'youtube_id', 'youtubeId', 'lecture_id', 'id'])
const isHttpUrl = (value: string) => /^https?:\/\//i.test(value)

function unwrap(data: any): any {
  if (typeof data === 'string') {
    try { return JSON.parse(data) } catch { return data }
  }
  const obj = asObject(data)
  for (const key of ['data', 'result', 'results', 'response', 'payload']) {
    if (obj[key] !== undefined && obj[key] !== null) return unwrap(obj[key])
  }
  return data
}

function findArray(data: any): any[] {
  const unwrapped = unwrap(data)
  if (Array.isArray(unwrapped)) return unwrapped
  const obj = asObject(unwrapped)
  for (const key of ['courses', 'items', 'results', 'list', 'data', 'contents', 'content', 'subjects', 'chapters', 'lectures', 'videos', 'folders', 'sections']) {
    if (Array.isArray(obj[key])) return obj[key]
  }
  // Search shallowly for a likely list, without assuming a particular schema.
  for (const value of Object.values(obj)) if (Array.isArray(value)) return value
  return []
}

export function normalizeCourses(payload: any): Course[] {
  const rows = findArray(payload)
  return rows.map((entry: any, index: number) => {
    const obj = asObject(entry)
    const id = idField(obj) || textField(obj, ['slug', 'course_code', 'code'])
    return {
      id,
      title: titleField(obj) || `Untitled course ${index + 1}`,
      description: descriptionField(obj),
      thumbnail: imageField(obj),
      teacher: textField(obj, ['teacher', 'teacher_name', 'instructor', 'faculty', 'author']) || undefined,
      category: textField(obj, ['category', 'class', 'grade', 'target']) || undefined,
      raw: obj,
    }
  }).filter(course => Boolean(course.id))
}

function isLikelyVideo(obj: Raw): boolean {
  const keys = ['video_id', 'videoId', 'videoid', 'youtube_id', 'youtubeId', 'play_url', 'video_url', 'videoUrl', 'stream_url', 'streamUrl', 'url']
  return keys.some(key => obj[key] !== undefined && obj[key] !== null && obj[key] !== '')
}

function normalizeContentNode(value: any): ContentItem | null
function normalizeContentNode(value: any, index: number): ContentItem | null
function normalizeContentNode(value: any, index = 0): ContentItem | null {
  if (value === null || value === undefined) return null
  const obj = asObject(value)
  if (!Object.keys(obj).length) return null
  const childrenValue = first(obj, ['children', 'items', 'contents', 'content', 'chapters', 'lectures', 'videos', 'folders', 'sections', 'lessons', 'topics', 'subtopics'])
  const children = Array.isArray(childrenValue)
    ? childrenValue.map((child: any, i: number) => normalizeContentNode(child, i)).filter(Boolean) as ContentItem[]
    : []
  const title = titleField(obj) || `Item ${index + 1}`
  const videoId = videoIdField(obj)
  const kind: ContentItem['kind'] = children.length ? 'folder' : (isLikelyVideo(obj) ? 'video' : 'item')
  const id = idField(obj) || videoId || `${title.toLowerCase().replace(/[^a-z0-9]+/g, '-')}-${index}`
  return {
    id, title, kind,
    thumbnail: imageField(obj) || undefined,
    duration: textField(obj, ['duration', 'length', 'time']) || undefined,
    description: descriptionField(obj) || undefined,
    videoId: videoId || undefined,
    children,
    raw: obj,
  }
}

export function normalizeCourseContent(payload: any): ContentItem[] {
  const data = unwrap(payload)
  const obj = asObject(data)
  // Prefer known content arrays, then any returned array.
  const rows = findArray(data)
  if (rows.length) return rows.map((row, i) => normalizeContentNode(row, i)).filter(Boolean) as ContentItem[]
  // Some APIs return one course object containing a nested hierarchy.
  const rootChildren = first(obj, ['children', 'items', 'contents', 'content', 'subjects', 'chapters', 'lectures', 'videos', 'folders', 'sections', 'lessons', 'topics'])
  if (Array.isArray(rootChildren)) return rootChildren.map((row: any, i: number) => normalizeContentNode(row, i)).filter(Boolean) as ContentItem[]
  // Search nested values for the first likely content array.
  for (const value of Object.values(obj)) {
    if (Array.isArray(value) && value.length) {
      const mapped = value.map((row, i) => normalizeContentNode(row, i)).filter(Boolean) as ContentItem[]
      if (mapped.length) return mapped
    }
  }
  return []
}

export function normalizeVideo(payload: any): VideoInfo | null {
  const data = unwrap(payload)
  const candidates: any[] = []
  const visit = (value: any, depth = 0) => {
    if (depth > 5 || value == null) return
    if (Array.isArray(value)) { value.forEach(v => visit(v, depth + 1)); return }
    if (typeof value !== 'object') return
    candidates.push(value)
    Object.values(value).forEach(v => { if (typeof v === 'object') visit(v, depth + 1) })
  }
  visit(data)
  const urlKeys = ['video_url', 'videoUrl', 'url', 'play_url', 'playUrl', 'stream_url', 'streamUrl', 'src', 'file', 'file_url', 'fileUrl', 'hls', 'mp4', 'embed_url', 'embedUrl', 'link']
  for (const obj of candidates) {
    const value = textField(obj, urlKeys)
    if (isHttpUrl(value)) {
      return { url: value, title: titleField(obj) || undefined, type: textField(obj, ['type', 'mime_type', 'mimeType']) || undefined, raw: obj }
    }
  }
  // Sometimes the response itself is a direct URL string.
  if (typeof data === 'string' && isHttpUrl(data.trim())) return { url: data.trim(), raw: {} }
  return null
}

export function summarizeApiError(error: unknown): string {
  return error instanceof Error ? error.message : 'Something went wrong while loading data.'
}
