import { AlertCircle, BookOpen, LoaderCircle, RefreshCw, SearchX } from 'lucide-react'

export function LoadingState({ label = 'Loading your learning space…' }: { label?: string }) {
  return <div className="state-panel"><LoaderCircle className="spin" size={30} /><strong>{label}</strong><span>Just a moment</span></div>
}
export function ErrorState({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return <div className="state-panel error-state"><span className="state-icon"><AlertCircle size={24} /></span><strong>Couldn't load this right now</strong><p>{message}</p>{onRetry && <button className="button button-primary" onClick={onRetry}><RefreshCw size={16} /> Try again</button>}</div>
}
export function EmptyState({ title = 'Nothing here yet', message = 'When content becomes available, it will appear here.', search = false }: { title?: string; message?: string; search?: boolean }) {
  const Icon = search ? SearchX : BookOpen
  return <div className="state-panel"><span className="state-icon"><Icon size={25} /></span><strong>{title}</strong><p>{message}</p></div>
}
