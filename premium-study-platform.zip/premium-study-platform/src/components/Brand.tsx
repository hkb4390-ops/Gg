import { BookOpen } from 'lucide-react'
import { Link } from 'react-router-dom'

export default function Brand() {
  return <Link to="/" className="brand" aria-label="StudySpace home">
    <span className="brand-mark"><BookOpen size={20} strokeWidth={2.2} /></span>
    <span>study<span className="brand-accent">space</span></span>
  </Link>
}
