import { useEffect, useMemo, useState } from 'react'
import { ArrowLeft, BookOpen, CheckCircle2, ChevronRight, CircleHelp, Clock3, Command, GraduationCap, Home, LibraryBig, Menu, Moon, Play, Search, Sparkles, Sun, X } from 'lucide-react'
import { Link, Route, Routes, useNavigate, useParams } from 'react-router-dom'
import Brand from './components/Brand'
import CourseCard from './components/CourseCard'
import ContentTree from './components/ContentTree'
import { EmptyState, ErrorState, LoadingState } from './components/States'
import { getAllCoursesRaw, getApiStatus, getCourseDetailsRaw, getVideoRaw, normalizeCourseContent, normalizeCourses, normalizeVideo, summarizeApiError } from './services/api'
import type { ContentItem, Course, VideoInfo } from './types'

function Header({ onSearch }: { onSearch: () => void }) {
  const [menuOpen, setMenuOpen] = useState(false)
  return <header className="site-header">
    <div className="header-inner">
      <Brand />
      <nav className={`main-nav ${menuOpen ? 'nav-open' : ''}`}>
        <Link to="/" onClick={() => setMenuOpen(false)}><Home size={16} /> Home</Link>
        <Link to="/courses" onClick={() => setMenuOpen(false)}><LibraryBig size={16} /> Courses</Link>
      </nav>
      <div className="header-actions">
        <button className="search-trigger" onClick={onSearch}><Search size={17} /><span>Search courses</span><kbd>⌘ K</kbd></button>
        <button className="icon-button mobile-menu" aria-label="Toggle menu" onClick={() => setMenuOpen(v => !v)}>{menuOpen ? <X size={20} /> : <Menu size={20} />}</button>
      </div>
    </div>
  </header>
}

function AppShell() {
  const [searchOpen, setSearchOpen] = useState(false)
  const [dark, setDark] = useState(true)
  useEffect(() => { document.documentElement.dataset.theme = dark ? 'dark' : 'light' }, [dark])
  useEffect(() => {
    const handler = (e: KeyboardEvent) => { if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); setSearchOpen(true) } if (e.key === 'Escape') setSearchOpen(false) }
    window.addEventListener('keydown', handler)
    return () => window.removeEventListener('keydown', handler)
  }, [])
  return <div className="app-shell">
    <Header onSearch={() => setSearchOpen(true)} />
    <Routes>
      <Route path="/" element={<HomePage />} />
      <Route path="/courses" element={<CoursesPage />} />
      <Route path="/search" element={<CoursesPage />} />
      <Route path="/course/:courseId" element={<CoursePage />} />
      <Route path="/watch/:videoId" element={<WatchPage />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
    <footer className="site-footer"><div className="footer-inner"><Brand /><span>Make room for what you want to learn.</span><span className="footer-right">© {new Date().getFullYear()} StudySpace</span></div></footer>
    {searchOpen && <SearchOverlay onClose={() => setSearchOpen(false)} />}
    <button className="theme-toggle" aria-label="Toggle color theme" onClick={() => setDark(v => !v)}>{dark ? <Sun size={17} /> : <Moon size={17} />}</button>
  </div>
}

function useCourses() {
  const [courses, setCourses] = useState<Course[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [reload, setReload] = useState(0)
  useEffect(() => {
    let alive = true
    setLoading(true); setError('')
    getAllCoursesRaw().then(data => { if (alive) setCourses(normalizeCourses(data)) })
      .catch(err => { if (alive) setError(summarizeApiError(err)) })
      .finally(() => { if (alive) setLoading(false) })
    return () => { alive = false }
  }, [reload])
  return { courses, loading, error, retry: () => setReload(v => v + 1) }
}

function HomePage() {
  const { courses, loading, error, retry } = useCourses()
  const navigate = useNavigate()
  const [status, setStatus] = useState<'checking' | 'ok' | 'warning'>('checking')
  useEffect(() => { getApiStatus().then(() => setStatus('ok')).catch(() => setStatus('warning')) }, [])
  return <main>
    <section className="hero-section">
      <div className="hero-orb orb-one" /><div className="hero-orb orb-two" />
      <div className="hero-content">
        <div className="eyebrow"><span className="eyebrow-dot" /> YOUR NEXT CHAPTER STARTS HERE</div>
        <h1>Learn something<br /><span>that moves you.</span></h1>
        <p className="hero-copy">Your courses, your pace, your progress. Find a lesson and get into the flow.</p>
        <div className="hero-buttons"><button className="button button-primary" onClick={() => navigate('/courses')}>Explore courses <ChevronRight size={17} /></button><a href="#all-courses" className="button button-quiet">See what's available</a></div>
        <div className="hero-meta"><span><CheckCircle2 size={15} /> Learn at your own pace</span><span><Sparkles size={15} /> One lesson at a time</span></div>
      </div>
      <div className="hero-art" aria-hidden="true">
        <div className="art-halo" /><div className="art-card art-card-back"><div className="art-lines"><i /><i /><i /></div></div>
        <div className="art-card art-card-main"><div className="art-top"><span className="art-dot" /><span className="art-dot" /><span className="art-dot" /><span className="art-label">LEARNING SPACE</span></div><div className="art-book"><BookOpen size={48} /></div><div className="art-title">A little progress<br />every day.</div><div className="art-progress"><span /><span /><span /><span /><span /><span /><span /></div><div className="art-caption">YOUR JOURNEY, YOUR WAY</div></div>
        <div className="floating-pill pill-top"><GraduationCap size={16} /> Keep growing</div><div className="floating-pill pill-bottom"><Play size={15} fill="currentColor" /> Press play. Begin.</div>
      </div>
    </section>
    <section className="content-section" id="all-courses">
      <div className="section-heading"><div><span className="section-kicker">YOUR LIBRARY</span><h2>Explore courses<span className="heading-period">.</span></h2><p>Find the course you want to pick up next.</p></div><Link to="/courses" className="text-link">View all courses <ChevronRight size={16} /></Link></div>
      {loading ? <CourseSkeletons /> : error ? <ErrorState message={error} onRetry={retry} /> : courses.length ? <div className="course-grid">{courses.slice(0, 8).map((course, i) => <CourseCard key={course.id} course={course} index={i} />)}</div> : <EmptyState title="No courses found" message="The API returned no course records. Try again later." />}
      {!loading && !error && courses.length > 8 && <div className="center-action"><Link to="/courses" className="button button-secondary">Browse all {courses.length} courses <ChevronRight size={17} /></Link></div>}
      <div className={`api-status ${status === 'ok' ? 'status-ok' : status === 'warning' ? 'status-warning' : ''}`}><span className="status-dot" />{status === 'checking' ? 'Checking learning service…' : status === 'ok' ? 'Learning service responded' : 'Learning service status unavailable'}<span className="status-note">Course loading is checked separately</span></div>
    </section>
    <section className="bottom-banner"><div className="banner-icon"><Command size={23} /></div><div><strong>Small steps add up.</strong><p>Choose a course, find a lesson, and keep your momentum going.</p></div><Link to="/courses" className="banner-link">Start learning <ChevronRight size={16} /></Link></section>
  </main>
}

function CourseSkeletons() {
  return <div className="course-grid">{Array.from({ length: 4 }, (_, i) => <div className="course-skeleton" key={i}><div className="skeleton-cover shimmer" /><div className="skeleton-line shimmer" /><div className="skeleton-line short shimmer" /></div>)}</div>
}

function CoursesPage() {
  const { courses, loading, error, retry } = useCourses()
  const [query, setQuery] = useState('')
  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase()
    if (!q) return courses
    return courses.filter(c => [c.title, c.description, c.teacher, c.category].some(v => v?.toLowerCase().includes(q)))
  }, [courses, query])
  return <main className="page-wrap">
    <div className="page-intro"><Link to="/" className="back-link"><ArrowLeft size={16} /> Home</Link><span className="section-kicker">THE COURSE LIBRARY</span><h1>All courses<span className="heading-period">.</span></h1><p>Pick a course and continue at your own pace.</p></div>
    <div className="library-tools"><div className="search-field"><Search size={18} /><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search courses, topics, teachers…" aria-label="Search courses" />{query && <button onClick={() => setQuery('')} aria-label="Clear search"><X size={16} /></button>}</div><span className="result-count">{loading ? 'Loading…' : `${filtered.length} ${filtered.length === 1 ? 'course' : 'courses'}`}</span></div>
    {loading ? <CourseSkeletons /> : error ? <ErrorState message={error} onRetry={retry} /> : filtered.length ? <div className="course-grid">{filtered.map((c, i) => <CourseCard key={c.id} course={c} index={i} />)}</div> : <EmptyState search={Boolean(query)} title={query ? 'No matching courses' : 'No courses available'} message={query ? 'Try another keyword or clear your search.' : 'The API did not return any courses. Please try again later.'} />}
  </main>
}

function CoursePage() {
  const { courseId = '' } = useParams()
  const navigate = useNavigate()
  const { courses } = useCourses()
  const [data, setData] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [reload, setReload] = useState(0)
  useEffect(() => {
    let alive = true
    setLoading(true); setError('')
    getCourseDetailsRaw(courseId).then(v => { if (alive) setData(v) }).catch(e => { if (alive) setError(summarizeApiError(e)) }).finally(() => { if (alive) setLoading(false) })
    return () => { alive = false }
  }, [courseId, reload])
  const course = courses.find(c => c.id === courseId)
  const content = useMemo(() => data ? normalizeCourseContent(data) : [], [data])
  const apiTitle = data && typeof data === 'object' ? (data.title || data.name || data.course_name || data.courseName || data.data?.title || data.data?.name) : ''
  const title = String(apiTitle || course?.title || 'Course details')
  const onPlay = (item: ContentItem) => {
    const id = item.videoId || (item.kind === 'video' ? item.id : '')
    if (!id) {
      window.alert('This item does not expose a video ID in the available API response.')
      return
    }
    navigate(`/watch/${encodeURIComponent(id)}`, { state: { title: item.title, courseId, courseTitle: title } })
  }
  return <main className="page-wrap course-page">
    <Link to="/courses" className="back-link"><ArrowLeft size={16} /> All courses</Link>
    {loading ? <LoadingState label="Opening course…" /> : error ? <ErrorState message={error} onRetry={() => setReload(v => v + 1)} /> : <>
      <section className="course-detail-hero">
        <div className="detail-copy"><span className="section-kicker">COURSE OVERVIEW</span><h1>{title}<span className="heading-period">.</span></h1>{(data?.description || data?.data?.description || course?.description) && <p>{data?.description || data?.data?.description || course?.description}</p>}<div className="detail-meta">{course?.teacher && <span><GraduationCap size={16} /> {course.teacher}</span>}<span><BookOpen size={16} /> Course content</span></div></div>
        <div className="detail-cover">{course?.thumbnail ? <img src={course.thumbnail} alt="" /> : <div className="cover-fallback large"><BookOpen size={45} /><span>STUDYSPACE</span></div>}</div>
      </section>
      <div className="section-heading content-heading"><div><span className="section-kicker">YOUR LEARNING PATH</span><h2>Course content<span className="heading-period">.</span></h2><p>Open a section to explore its available lessons.</p></div><span className="content-count">{countItems(content)} items</span></div>
      {content.length ? <ContentTree items={content} onPlay={onPlay} /> : <EmptyState title="No course content found" message="The course details response did not expose a recognizable content list. The API response structure may need a field mapping in src/services/api.ts." />}
    </>}
  </main>
}

function countItems(items: ContentItem[]): number {
  return items.reduce((sum, item) => sum + 1 + countItems(item.children), 0)
}

function WatchPage() {
  const { videoId = '' } = useParams()
  const navigate = useNavigate()
  const location = (window.history.state?.usr || {}) as { title?: string; courseId?: string; courseTitle?: string }
  const [video, setVideo] = useState<VideoInfo | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [reload, setReload] = useState(0)
  const [resume, setResume] = useState(0)
  const [saved, setSaved] = useState(false)
  const storageKey = `studyspace-progress-${videoId}`
  useEffect(() => {
    let alive = true
    setLoading(true); setError(''); setVideo(null)
    getVideoRaw(videoId).then(raw => {
      const normalized = normalizeVideo(raw)
      if (!normalized) throw new Error('The video API response did not contain a recognizable playable URL.')
      if (alive) setVideo(normalized)
    }).catch(err => { if (alive) setError(summarizeApiError(err)) }).finally(() => { if (alive) setLoading(false) })
    try { setResume(Number(localStorage.getItem(storageKey) || 0)) } catch { setResume(0) }
    return () => { alive = false }
  }, [videoId, reload, storageKey])
  const onTimeUpdate = (e: React.SyntheticEvent<HTMLVideoElement>) => {
    try { localStorage.setItem(storageKey, String(Math.floor(e.currentTarget.currentTime))) } catch {}
  }
  const onLoaded = (e: React.SyntheticEvent<HTMLVideoElement>) => {
    const el = e.currentTarget
    if (resume > 5 && Number.isFinite(el.duration) && resume < el.duration - 5) el.currentTime = resume
  }
  const isHls = video?.url.toLowerCase().includes('.m3u8')
  return <main className="page-wrap watch-page">
    <button className="back-link back-button" onClick={() => location.courseId ? navigate(`/course/${encodeURIComponent(location.courseId)}`) : navigate(-1)}><ArrowLeft size={16} /> {location.courseTitle || 'Back to course'}</button>
    <div className="watch-layout">
      <section className="player-column">
        <div className="player-shell">
          {loading ? <LoadingState label="Preparing your lesson…" /> : error ? <ErrorState message={error} onRetry={() => setReload(v => v + 1)} /> : video && <>
            {isHls && <div className="media-notice">This lesson uses an HLS stream. If your browser does not support it natively, the API owner may need to provide a compatible player setup.</div>}
            <video className="video-player" controls playsInline preload="metadata" src={video.url} onTimeUpdate={onTimeUpdate} onLoadedMetadata={onLoaded} onEnded={() => { try { localStorage.setItem(storageKey, '0'); localStorage.setItem(`studyspace-complete-${videoId}`, '1') } catch {} }} />
          </>}
        </div>
        <div className="watch-title-row"><div><span className="section-kicker">NOW LEARNING</span><h1>{location.title || video?.title || 'Video lesson'}<span className="heading-period">.</span></h1><p>{location.courseTitle || 'Your learning session'}</p></div><button className={`save-button ${saved ? 'saved' : ''}`} onClick={() => { setSaved(v => !v); try { const key = 'studyspace-bookmarks'; const list = JSON.parse(localStorage.getItem(key) || '[]'); const next = saved ? list.filter((x: string) => x !== videoId) : [...new Set([...list, videoId])]; localStorage.setItem(key, JSON.stringify(next)) } catch {} }}><CheckCircle2 size={17} /> {saved ? 'Saved' : 'Save lesson'}</button></div>
        {video && <div className="video-source-note"><CircleHelp size={15} /> Playback depends on the format and access rules of the video source.</div>}
      </section>
      <aside className="watch-sidebar"><div className="sidebar-heading"><div><span className="section-kicker">YOUR SESSION</span><h3>Keep your focus.</h3></div><Clock3 size={21} /></div><div className="session-card"><span className="session-icon"><Play size={17} fill="currentColor" /></span><div><strong>One lesson at a time</strong><p>Your recent playback position is stored on this device when supported.</p></div></div><div className="session-tip"><Sparkles size={17} /><p>Take notes as you go and revisit key ideas when you need them.</p></div></aside>
    </div>
  </main>
}

function SearchOverlay({ onClose }: { onClose: () => void }) {
  const { courses, loading, error } = useCourses()
  const [query, setQuery] = useState('')
  const navigate = useNavigate()
  const results = useMemo(() => {
    const q = query.toLowerCase().trim()
    return q ? courses.filter(c => [c.title, c.description, c.teacher, c.category].some(v => v?.toLowerCase().includes(q))).slice(0, 6) : courses.slice(0, 4)
  }, [courses, query])
  return <div className="overlay-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) onClose() }}><section className="search-modal" role="dialog" aria-modal="true" aria-label="Search courses">
    <div className="modal-search"><Search size={20} /><input autoFocus value={query} onChange={e => setQuery(e.target.value)} placeholder="Search courses…" /><kbd>ESC</kbd><button className="icon-button" onClick={onClose} aria-label="Close search"><X size={19} /></button></div>
    <div className="modal-results">{loading ? <LoadingState label="Finding courses…" /> : error ? <p className="inline-error">{error}</p> : results.length ? results.map(course => <button className="search-result" key={course.id} onClick={() => { onClose(); navigate(`/course/${encodeURIComponent(course.id)}`) }}><span className="result-book"><BookOpen size={18} /></span><span><strong>{course.title}</strong><small>{course.category || course.teacher || 'Open course'}</small></span><ChevronRight size={17} /></button>) : <EmptyState search title="No results" message="Try a different course name." />}</div>
    <div className="modal-footer"><span>Search across available course information</span><Link to="/courses" onClick={onClose}>Browse all courses <ChevronRight size={14} /></Link></div>
  </section></div>
}

function NotFound() {
  return <main className="page-wrap not-found"><div className="not-found-icon"><CircleHelp size={34} /></div><span className="section-kicker">PAGE NOT FOUND</span><h1>We lost that page<span className="heading-period">.</span></h1><p>The link may be outdated or the page may have moved.</p><Link to="/" className="button button-primary">Back to home <ChevronRight size={17} /></Link></main>
}

export default function App() {
  return <AppShell />
}
