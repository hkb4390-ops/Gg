import { ArrowUpRight, BookOpen, Play } from 'lucide-react'
import { Link } from 'react-router-dom'
import type { Course } from '../types'

export default function CourseCard({ course, index = 0 }: { course: Course; index?: number }) {
  return <Link to={`/course/${encodeURIComponent(course.id)}`} className="course-card" style={{ animationDelay: `${Math.min(index, 10) * 35}ms` }}>
    <div className="course-cover">
      {course.thumbnail
        ? <img src={course.thumbnail} alt="" loading="lazy" onError={e => { e.currentTarget.style.display = 'none' }} />
        : <div className="cover-fallback"><BookOpen size={34} /><span>STUDYSPACE</span></div>}
      <span className="cover-play"><Play size={17} fill="currentColor" /></span>
      {course.category && <span className="course-chip">{course.category}</span>}
    </div>
    <div className="course-card-body">
      <h3>{course.title}</h3>
      {course.description && <p>{course.description}</p>}
      <div className="course-card-bottom">
        <span>{course.teacher || 'Course'}</span>
        <span className="card-arrow"><ArrowUpRight size={17} /></span>
      </div>
    </div>
  </Link>
}
