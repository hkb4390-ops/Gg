import { useState } from 'react'
import { ChevronDown, ChevronRight, CirclePlay, Folder, FolderOpen, PlayCircle } from 'lucide-react'
import type { ContentItem } from '../types'

function Node({ item, depth, onPlay }: { item: ContentItem; depth: number; onPlay: (item: ContentItem) => void }) {
  const [open, setOpen] = useState(depth === 0)
  const hasChildren = item.children.length > 0
  const isPlayable = Boolean(item.videoId) || item.kind === 'video'
  return <div className="tree-node">
    <button className={`content-row ${isPlayable ? 'is-lecture' : ''}`} style={{ '--depth': depth } as React.CSSProperties}
      onClick={() => hasChildren ? setOpen(v => !v) : onPlay(item)}
      aria-expanded={hasChildren ? open : undefined}>
      <span className="content-row-icon">
        {hasChildren ? (open ? <FolderOpen size={19} /> : <Folder size={19} />) : isPlayable ? <CirclePlay size={19} /> : <Folder size={19} />}
      </span>
      <span className="content-row-text"><strong>{item.title}</strong>{item.description && <small>{item.description}</small>}</span>
      {item.duration && <span className="lecture-duration">{item.duration}</span>}
      {hasChildren ? (open ? <ChevronDown size={17} /> : <ChevronRight size={17} />) : isPlayable ? <PlayCircle size={19} className="row-play" /> : <ChevronRight size={17} />}
    </button>
    {hasChildren && open && <div className="tree-children">{item.children.map((child, i) => <Node key={`${child.id}-${i}`} item={child} depth={depth + 1} onPlay={onPlay} />)}</div>}
  </div>
}

export default function ContentTree({ items, onPlay }: { items: ContentItem[]; onPlay: (item: ContentItem) => void }) {
  return <div className="content-tree">{items.map((item, i) => <Node key={`${item.id}-${i}`} item={item} depth={0} onPlay={onPlay} />)}</div>
}
